#ifndef _CSBOBO_STM32F4XX_DELAY_H
#define _CSBOBO_STM32F4XX_DELAY_H 			   
#include "stm32f4xx.h" 

void delay_us(u32 nTimer);
void delay_ms(u32 nTimer);
#endif





























