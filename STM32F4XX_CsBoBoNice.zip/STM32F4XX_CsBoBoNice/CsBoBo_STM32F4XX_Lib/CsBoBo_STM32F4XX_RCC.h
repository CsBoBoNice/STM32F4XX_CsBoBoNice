#ifndef _CSBOBO_STM32F4XX_RCC_H_
#define _CSBOBO_STM32F4XX_RCC_H_
#include "stm32f4xx.h" 


void Stm32_Clock_Init(u32 plln,u32 pllm,u32 pllp,u32 pllq);	//ϵͳʱ�ӳ�ʼ������

#endif
