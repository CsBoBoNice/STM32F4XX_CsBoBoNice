#include "stm32f4xx.h"
#include "CsBoBo_STM32F4XX_LIB.h"



int main(void)
{
	NVIC_Configuration(NVIC_PriorityGroup_4);
	while (1)
	{
		
	}
}


